Chat
####

(I haven't got a better name yet)

A simple HTTP based chat system. Uses CookieLogin to authorize actions.

Currently under development.

Read This
*********

This is actually a testing module for CookieLogin right now.
I started developing this system for another purpose but it
is not suiting the requirements so I stopped developing it.

Most probably you found this python package in a zip to test
cookie login and this is the place to live for this package.

#!/usr/bin/python3

#
# Copyright(c) 2017 Daniel Knüttel
#

# This program is free software.
# Anyways if you think this program is worth it
# and we meet shout a drink for me.


#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Lesser General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Lesser General Public License for more details.
#
#    You should have received a copy of the GNU Lesser General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#    Dieses Programm ist Freie Software: Sie können es unter den Bedingungen
#    der GNU Lesser General Public License, wie von der Free Software Foundation,
#    Version 3 der Lizenz oder (nach Ihrer Wahl) jeder neueren
#    veröffentlichten Version, weiterverbreiten und/oder modifizieren.
#
#    Dieses Programm wird in der Hoffnung, dass es nützlich sein wird, aber
#    OHNE JEDE GEWÄHRLEISTUNG, bereitgestellt; sogar ohne die implizite
#    Gewährleistung der MARKTFÄHIGKEIT oder EIGNUNG FÜR EINEN BESTIMMTEN ZWECK.
#    Siehe die GNU Lesser General Public License für weitere Details.
#
#    Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit diesem
#    Programm erhalten haben. Wenn nicht, siehe <http://www.gnu.org/licenses/>.
import sys, os, math, datetime, json
dformat = "%d.%m.%m-%H:%M"
from ..model.chat import Chat
from ..model.entry import Entry

datatypes = ["text", "union", "latex", "md", "rst"]

class ChatAPI(object):
	"""
	An internal API. Used to access one Chat.
	
	"""
	def __init__(self, filename = None):

		if(filename == None):
			self.chat = Chat()
		else:
			try:
				self.chat = Chat.from_json(open(filename).read())
			except:
				self.chat = Chat(filename = filename)
		self.filename = self.chat.filename
	def push_text(self, author, text):
		"""
		Push a simple text message.
		"""
		if(not self.chat.is_registered(author)):
			raise Exception( "err: user not registered")
		self.chat.add_entry(Entry(author, datetime.datetime.now().strftime(dformat), "text", text))
	def pull_messages_json(self, author):
		"""
		Pull all messages in JSON format.
		"""
		if(not self.chat.is_registered(author)):
			raise Exception( "err: user not registered")
		return self.chat.to_json()
	def push_message(self, author, dtype, content):
		"""
		Push a message.
		"""
		if(not self.chat.is_registered(author)):
			raise Exception( "err: user not registered")
		dtype = dtype.replace("'", "").replace('"', "")
		if(not dtype in datatypes):
			raise Exception("dtype not supported: {}".format(dtype))
		self.chat.add_entry(Entry(author, datetime.datetime.now().strftime(dformat), dtype, content))
	def clear_messages(self, author):
		"""
		Remove all entries in the chat.
		"""
		if(not self.chat.is_moderator(author)):
			raise Exception( "err: user is no moderator")
		self.chat.entries = []
	def push_union(self, author, item1dtype, item1, item2dtype, item2):
		"""
		Push an union Entry to the chat.
		"""
		if(not self.chat.is_registered(author)):
			raise Exception( "err: user not registered")
		if(not item1dtype in datatypes):
			raise Exception("dtype not supported: {}".format(item1dtype))
		if(not item2dtype in datatypes):
			raise Exception("dtype not supported: {}".format(item2dtype))

		data = {"item1": {"dtype": item1dtype, "content": item1}, "item2": {"dtype": item2dtype, "content": item2}}
		self.chat.add_entry(Entry(author, datetime.datetime.now().strftime(dformat), "union", json.dumps(data)))

	
	def delete_from(self, author, date):
		"""
		Sets the type of the entry that ``author`` has written at ``date``
		to DELETED and sets the content to ``"DELETED on <date>"``.
		"""
		if(not self.chat.is_registered(author)):
			raise Exception( "err: user not registered")
		for entry in self.chat.entries:
			if(entry.author == author and entry.date == date):
				entry.dtype = "DELETED"
				entry.content = "DELETED on " + datetime.datetime.now().strftime(dformat)
				return "OK"
		return "err: not found"
	def to_dict(self):
		"""
		Convert this API to a dict representation.
		"""
		return {"filename": self.filename}
	@staticmethod
	def from_dict(dct):
		"""
		Use a dict to create the API.
		"""
		return ChatAPI(dct["filename"])
	

		
	

class API(object):
	"""
	Internal API used to access mutliple Chats.
	"""
	def __init__(self, path_prefix, chat_path_template = "chat-{id}-{name}/", chat_file_name = "chat.json", filename = "api.json"):
		self.path_prefix = path_prefix
		self.chat_path_template = chat_path_template
		self.chats_by_ID = {}
		self.chats_by_name = {}
		self.names_by_ID = {}
		self.id_counter = 0
		self.chat_file_name = chat_file_name

		self.id_pull_methods = {"json": self.id_pull_messages_json}
		self.name_pull_methods = {"json": self.name_pull_messages_json}
		self.filename = filename

	def add_chat(self, name):
		"""
		Create a new chat entity. Will create a correspondig path.

		Returns the corresponding API.
		"""
		if(name in self.chats_by_name):
			raise Exception("Chat with name {} does already exist".format(name))

		chat_path = self.path_prefix + self.chat_path_template.format(id = self.id_counter, name = name)
		# make a directory for this chat...
		if(not os.path.exists(chat_path)):
			os.makedirs(chat_path)
		chat = Chat(filename = chat_path + self.chat_file_name)
		# write an initial file
		chat.dump_with_meta()


		# create the API for this chat instance
		api = ChatAPI(filename = chat_path + self.chat_file_name)


		# store the entry
		self.chats_by_ID[self.id_counter] = api
		self.names_by_ID[self.id_counter] = name
		self.chats_by_name[name] = api
		self.id_counter += 1
		return api
	def to_dict(self):
		"""
		Convert this API to a dict representation.
		"""
		return {"path_prefix": self.path_prefix,
			"chat_path_template": self.chat_path_template,
			"chat_file_name": self.chat_file_name,
			"chats_by_name": {k: v.to_dict() for k, v in self.chats_by_name.items()},
			"names_by_ID": self.names_by_ID}
	def to_json(self):
		"""
		Convert this API to a JSON representation.
		"""
		return json.dumps(self.to_dict())

	@staticmethod
	def from_dict(dct):
		"""
		Convert a dict representation to an API object.
		"""
		id_and_name = {int(k): v for k,v in dct["names_by_ID"].items()}
		ids = [i for i,n in id_and_name.items()]
		api = API(dct["path_prefix"], chat_path_template = dct["chat_path_template"],
				chat_file_name = dct["chat_file_name"])
		# set up the ID management
		api.names_by_ID = id_and_name
		api.id_counter = max(ids) + 1
		
		# reverse this to access the ID faster
		id_and_name = {v:k for k, v in id_and_name.items()}

		for name, chat_api_dict in dct["chats_by_name"].items():
			chat_api = ChatAPI.from_dict(chat_api_dict)
			# insert this chat
			api.chats_by_name[name] = chat_api
			api.chats_by_ID[id_and_name[name]] = chat_api
		return api


	@staticmethod
	def from_json(json_string):
		"""
		Convert a JSON representation to an API object.
		"""
		return API.from_dict(json.loads(json_string))


	def save(self, filename = None):
		"""
		Save this API object as JSON and all the chats.
		"""
		if(filename == None):
			filename = self.path_prefix + self.filename
		f = open(filename, "w")
		f.write(self.to_json())
		f.close()

		for _, chat_api in self.chats_by_ID.items():
			chat_api.chat.dump_with_meta()

		


	def id_push_text(self, id, author, text):
		"""
		Push a simple text message. Access the chat via ID.
		"""
		if(not id in self.chats_by_ID):
			raise Exception("chat not found")
		return self.chats_by_ID[id].push_text(author, text)
	def id_pull_messages_json(self, id, author):
		"""
		Pull all messages in JSON format. Access the chat via ID.
		"""
		if(not id in self.chats_by_ID):
			raise Exception("chat not found")
		return self.chats_by_ID[id].pull_messages_json(author)
	def id_push_message(self, id, author, dtype, content):
		"""
		Push a message. Access the chat via ID.
		"""
		if(not id in self.chats_by_ID):
			raise Exception("chat not found")
		return self.chats_by_ID[id].push_message(author, dtype, content)
	def id_clear_messages(self, id, author):
		"""
		Remove all entries in the chat. Access the chat via ID.
		"""
		if(not id in self.chats_by_ID):
			raise Exception("chat not found")
		return self.chats_by_ID[id].clear_messages(author)
	def id_push_union(self, id, author, item1dtype, item1, item2dtype, item2):
		"""
		Push an union Entry to the chat. Access the chat via ID.
		"""
		if(not id in self.chats_by_ID):
			raise Exception("chat not found")
		return self.chats_by_ID[id].push_text(author, item1dtype, item1, item2dtype, item2)
	

	
	def name_push_text(self, name, author, text):
		"""
		Push a simple text message. Access the chat via name.
		"""
		if(not name in self.chats_by_name):
			raise Exception("chat not found")
		return self.chats_by_name[name].push_text(author, text)
	def name_pull_messages_json(self, name, author):
		"""
		Pull all messages in JSON format. Access the chat via name.
		"""
		if(not name in self.chats_by_name):
			raise Exception("chat not found")
		return self.chats_by_name[name].pull_messages_json(author)
	def name_push_message(self, name, author, dtype, content):
		"""
		Push a message. Access the chat via name.
		"""
		if(not name in self.chats_by_name):
			raise Exception("chat not found")
		return self.chats_by_name[name].push_message(author, dtype, content)
	def name_clear_messages(self, name, author):
		"""
		Remove all entries in the chat. Access the chat via name.
		"""
		if(not name in self.chats_by_name):
			raise Exception("chat not found")
		return self.chats_by_name[name].clear_messages(author)
	def name_push_union(self, name, author, item1dtype, item1, item2dtype, item2):
		"""
		Push an union Entry to the chat. Access the chat via name.
		"""
		if(not name in self.chats_by_name):
			raise Exception("chat not found")
		return self.chats_by_name[name].push_text(author, item1dtype, item1, item2dtype, item2)

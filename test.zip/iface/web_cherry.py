#!/usr/bin/python3

#
# Copyright(c) 2017 Daniel Knüttel
#

# This program is free software.
# Anyways if you think this program is worth it
# and we meet shout a drink for me.


#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Lesser General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Lesser General Public License for more details.
#
#    You should have received a copy of the GNU Lesser General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#    Dieses Programm ist Freie Software: Sie können es unter den Bedingungen
#    der GNU Lesser General Public License, wie von der Free Software Foundation,
#    Version 3 der Lizenz oder (nach Ihrer Wahl) jeder neueren
#    veröffentlichten Version, weiterverbreiten und/oder modifizieren.
#
#    Dieses Programm wird in der Hoffnung, dass es nützlich sein wird, aber
#    OHNE JEDE GEWÄHRLEISTUNG, bereitgestellt; sogar ohne die implizite
#    Gewährleistung der MARKTFÄHIGKEIT oder EIGNUNG FÜR EINEN BESTIMMTEN ZWECK.
#    Siehe die GNU Lesser General Public License für weitere Details.
#
#    Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit diesem
#    Programm erhalten haben. Wenn nicht, siehe <http://www.gnu.org/licenses/>.
from ..api.basic import API
import cherrypy, os, json, datetime
from email.mime.image import MIMEImage
from email.mime.audio import MIMEAudio

"""
A webinterface for the chat system using cherrypy.
"""


class WebIface(object):
	"""
	A simple webinterface for the Chat system.
	Uses a ``..api.basic.API`` instance to access the chat.

	You have to provide a loginmanager with a method ``isvalid``
	that will check a login of type ``dict`` for validity.

	"""
	def __init__(self, loginmanager, path_prefix = "./", chat_filename = "chat.json", path_template = "chat-{id}-{name}/", api_fname = "api.json"):
		if(not os.path.exists(path_prefix + api_fname)):
			self.api = API(path_prefix = path_prefix, 
					chat_path_template = path_template, 
					chat_file_name = chat_filename)
			self.api.add_chat("default")
		else:
			f = open(path_prefix + api_fname)
			self.api = API.from_json(f.read())
			f.close()

		self.loginmanager = loginmanager

	@cherrypy.expose
	def push(self, login, dtype, msg, chat_id = None, chat_name = None):
		"""
		Push a message to the chat.
		Returns either a error message starting with ``"err:"`` or ``"OK"``.
		"""

		if(chat_id == None and chat_name == None):
			return "err: no chat specified"

		login = json.loads(login)
		try:
			if(not self.loginmanager.isvalid(login)):
				return "err: invalid login"
		except Exception as e:
			return "err: " + str(e)
		author = login["name"]
		try:
			if(chat_id != None):
				self.api.id_push_message(int(chat_id), author, dtype, msg)
			elif(name != None):
				self.api.name_push_message(chat_name, author, dtype, msg)
		except Exception as e:
			print(e)
			return "err: " + str(e)

		return "OK"
	
	@cherrypy.expose
	def pull_messages(self, login, type = "json", chat_id = None, chat_name = None):
		"""
		Pull all messages from the chat using the format ``type``.
		Currently supported formats:

		- JSON

		Returns either a error message starting with ``"err:"`` or 
		the result.
		"""
		self.api.save()

		if(chat_id == None and chat_name == None):
			return "err: no chat specified"
		login = json.loads(login)
		try:
			if(not self.loginmanager.isvalid(login)):
				return "err: invalid login"
		except Exception as e:
			return "err: " + str(e)

		else:
			try:
				if(chat_id != None):
					if(not type in self.api.id_pull_methods):
						return "err: type not supported"
					return self.api.id_pull_methods[type](int(chat_id), login["name"])
				elif(name != None):
					if(not type in self.api.name_pull_methods):
						return "err: type not supported"
					return self.api.name_pull_methods[type](chat_name, login["name"])
			except Exception as e:
				return str(e)
	
	@cherrypy.expose
	def clear_messages(self, login, chat_id = None, chat_name = None):
		"""
		Remove all messages from the chat.
		Returns either a error message starting with ``"err:"`` or ``"OK"``.
		"""

		if(chat_id == None and chat_name == None):
			return "err: no chat specified"
		login = json.loads(login)
		try:
			if(not self.loginmanager.isvalid(login)):
				return "err: invalid login"
		except Exception as e:
			return "err: " + str(e)

		try:
			if(chat_id != None):
				self.api.id_clear_messages(int(chat_id), login["name"])
			elif(name != None):
				self.api.name_clear_messages(chat_name, login["name"])
		except Exception as e:
			return str(e)
		return "OK"
	@cherrypy.expose
	def push_image(self, login, image, description = "", chat_id = None, chat_name = None):
		"""
		Prefered way to push an Image. This will convert the image to
		MIME text and add a union Entry to the chat.
		"""

		if(chat_id == None and chat_name == None):
			return "err: no chat specified"
		login = json.loads(login)
		try:
			if(not self.loginmanager.isvalid(login)):
				return "err: invalid login"
		except Exception as e:
			return "err: " + str(e)

		# FIXME: make this more efficient.
		author = login["name"]
		mime = MIMEImage(image)
		image = mime.as_string()

		try:
			if(chat_id != None):
				self.api.id_push_union(int(chat_id), author, "image", image, "text", description)
			elif(name != None):
				self.api.name_push_union(chat_name, author, "image", image, "text", description)
		except Exception as e:
			return str(e)
		return "OK"
	@cherrypy.expose
	def push_audio(self, login, audio, description = "", chat_id = None, chat_name = None):
		"""
		Push audio data to the chat. Converts the audio to MIME text
		and adds a union Entry.
		"""

		if(chat_id == None and chat_name == None):
			return "err: no chat specified"
		login = json.loads(login)
		try:
			if(not self.loginmanager.isvalid(login)):
				return "err: invalid login"
		except Exception as e:
			return "err: " + str(e)

		# FIXME: make this more efficient.
		author = login["name"]
		mime = MIMEAudio(audio)
		audio = mime.as_string()

		try:
			if(chat_id != None):
				self.api.id_push_union(int(chat_id), author, "audio", audio, "text", description)
			elif(name != None):
				self.api.name_push_union(chat_name, author, "audio", audio, "text", description)
		except Exception as e:
			return str(e)
		return "OK"
	@cherrypy.expose
	def delety_my(self, login, date, chat_id = None, chat_name = None):
		"""
		Deletes the message that this user pushed at ``date``.
		"""

		if(chat_id == None and chat_name == None):
			return "err: no chat specified"
		login = json.loads(login)
		try:
			if(not self.loginmanager.isvalid(login)):
				return "err: invalid login"
		except Exception as e:
			return "err: " + str(e)

		author = login["name"]
		try:
			if(chat_id != None):
				return self.api.id_delete_from(int(chat_id), author, date)
			elif(name != None):
				return self.api.name_delete_from(chat_name, author, date)
		except Exception as e:
			return str(e)
		


	

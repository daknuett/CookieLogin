# coding: utf-8
import Crypto.PublicKey.RSA as RSA
import os
key = RSA.generate(1024,os.urandom)
foreign_key = RSA.generate(1024,os.urandom)
pubkeys = [key.publickey(), foreign_key.publickey()]
data = {"key": key, "foreign_key": foreign_key, "pubkeys": pubkeys} 
import pickle
	
with open("key-data.pik", "wb") as f:
	pickle.dump(data, f)
	

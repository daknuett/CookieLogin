#!/usr/bin/python3

#
# Copyright(c) 2017 Daniel Knüttel
#

# This program is free software.
# Anyways if you think this program is worth it
# and we meet shout a drink for me.


#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Lesser General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Lesser General Public License for more details.
#
#    You should have received a copy of the GNU Lesser General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#    Dieses Programm ist Freie Software: Sie können es unter den Bedingungen
#    der GNU Lesser General Public License, wie von der Free Software Foundation,
#    Version 3 der Lizenz oder (nach Ihrer Wahl) jeder neueren
#    veröffentlichten Version, weiterverbreiten und/oder modifizieren.
#
#    Dieses Programm wird in der Hoffnung, dass es nützlich sein wird, aber
#    OHNE JEDE GEWÄHRLEISTUNG, bereitgestellt; sogar ohne die implizite
#    Gewährleistung der MARKTFÄHIGKEIT oder EIGNUNG FÜR EINEN BESTIMMTEN ZWECK.
#    Siehe die GNU Lesser General Public License für weitere Details.
#
#    Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit diesem
#    Programm erhalten haben. Wenn nicht, siehe <http://www.gnu.org/licenses/>.

import json
from .entry import Entry

class Chat(object):
	"""
	Represents a Chat.
	"""
	def __init__(self, users = [], mods = [], filename = "default_chat.json", max_entries = 40):
		self.filename = filename
		self.max_entries = max_entries
		self.entries = []
		self.users = users
		self.mods = mods

	def is_moderator(self, username):
		"""
		Check if the user is a moderator.
		"""
		return username in self.mods
	def is_registered(self, username):
		"""
		Check if the user is registered (=> is able to pull/push messages).
		"""
		return username in self.users

	def add_entry(self, entry):
		"""
		Add an entry of type model.entry.Entry
		"""
		if(len(self.entries) < self.max_entries):
			self.entries.append(entry)
		else:
			self.entries = self.entries[len(self.entries) - self.max_entries + 1:]
			self.entries.append(entry)
	def to_dict_with_meta(self):
		"""
		Return a dict representation of the Chat including meta data.
		"""
		return {"meta":{"filename": self.filename,
				"max_entries": self.max_entries,
				"users": self.users,
				"moderators": self.mods},
		       "content": [entry.to_dict() for entry in self.entries]}

	def to_json(self):
		"""
		Return a json representation of the object.
		Does not include metadata.
		"""
		return json.dumps([entry.to_dict() for entry in self.entries])
	def to_json_with_meta(self):
		"""
		Return a json representation of the object.
		Includes metadata.
		"""
		return json.dumps(self.to_dict_with_meta())

	@staticmethod
	def from_json(json_string):
		"""
		Converts a JSON string into a Chat object.
		"""
		data = json.loads(json_string)
		if("meta" in json_string):
			fname = data["meta"]["filename"]
			users = data["meta"]["users"]
			moderators = data["meta"]["moderators"]
			max_entries = data["meta"]["max_entries"]
			chat = Chat(fname, max_entries)
			chat.users = users
			chat.mods = moderators

			data = data["content"]

		else:
			chat = Chat()
		entries = [Entry.from_dict(ent) for ent in data]
		chat.entries = entries
		return chat
	def dump(self, filename = None):
		"""
		Write a JSON representation into the file ``filename`` or (if not specified) ``self.filename``.
		Does not include meta data.
		"""
		if(filename == None):
			filename = self.filename
		f = open(filename, "w")
		f.write(self.to_json())
		f.close()
		
	def dump_with_meta(self, filename = None):
		"""
		Write a JSON representation into the file ``filename`` or (if not specified) ``self.filename``.
		Does include meta data.
		"""
		if(filename == None):
			filename = self.filename
		f = open(filename, "w")
		f.write(self.to_json_with_meta())
		f.close()
	

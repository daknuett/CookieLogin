#!/usr/bin/python3


#
# Copyright(c) 2017 Daniel Knüttel
#

# This program is free software.
# Anyways if you think this program is worth it
# and we meet shout a drink for me.


#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Lesser General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Lesser General Public License for more details.
#
#    You should have received a copy of the GNU Lesser General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#    Dieses Programm ist Freie Software: Sie können es unter den Bedingungen
#    der GNU Lesser General Public License, wie von der Free Software Foundation,
#    Version 3 der Lizenz oder (nach Ihrer Wahl) jeder neueren
#    veröffentlichten Version, weiterverbreiten und/oder modifizieren.
#
#    Dieses Programm wird in der Hoffnung, dass es nützlich sein wird, aber
#    OHNE JEDE GEWÄHRLEISTUNG, bereitgestellt; sogar ohne die implizite
#    Gewährleistung der MARKTFÄHIGKEIT oder EIGNUNG FÜR EINEN BESTIMMTEN ZWECK.
#    Siehe die GNU Lesser General Public License für weitere Details.
#
#    Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit diesem
#    Programm erhalten haben. Wenn nicht, siehe <http://www.gnu.org/licenses/>.
import sys, os, math, json

class Entry(object):
	"""
	Represents a chat entry( a message). 
	"""
	def __init__(self, author, datetime, dtype, content):
		self.author = author
		self.datetime = datetime
		self.dtype = dtype
		self.content = content
	def to_json(self):
		"""
		Return a JSON string representation.
		"""
		return json.dumps({"author": self.author, "datetime": self.datetime, "dtype": self.dtype, "content": self.content})
	def to_dict(self):
		"""
		Return a dict representation.
		"""
		return {"author": self.author, "datetime": self.datetime, "dtype": self.dtype, "content": self.content}

	@staticmethod
	def from_dict(dict_):
		"""
		Convert a dict into an Entry object.
		"""
		return Entry.__hook_from_json(dict_)
	@staticmethod
	def __hook_from_json(values):
		"""
		used by Entry.from_json
		"""
		return Entry(values["author"], values["datetime"], values["dtype"], values["content"])
	@staticmethod
	def from_json(json_string):
		"""
		Convert a JSON string into an Entry object.
		"""
		return json.loads(json_string, Entry.__hook_from_json)
	
		
		


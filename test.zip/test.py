#!/usr/bin/python3

#
# Copyright(c) 2017 Daniel Knüttel
#

# This program is free software.
# Anyways if you think this program is worth it
# and we meet shout a drink for me.


#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Lesser General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Lesser General Public License for more details.
#
#    You should have received a copy of the GNU Lesser General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#    Dieses Programm ist Freie Software: Sie können es unter den Bedingungen
#    der GNU Lesser General Public License, wie von der Free Software Foundation,
#    Version 3 der Lizenz oder (nach Ihrer Wahl) jeder neueren
#    veröffentlichten Version, weiterverbreiten und/oder modifizieren.
#
#    Dieses Programm wird in der Hoffnung, dass es nützlich sein wird, aber
#    OHNE JEDE GEWÄHRLEISTUNG, bereitgestellt; sogar ohne die implizite
#    Gewährleistung der MARKTFÄHIGKEIT oder EIGNUNG FÜR EINEN BESTIMMTEN ZWECK.
#    Siehe die GNU Lesser General Public License für weitere Details.
#
#    Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit diesem
#    Programm erhalten haben. Wenn nicht, siehe <http://www.gnu.org/licenses/>.
import cherrypy, hashlib, datetime
from .iface.web_cherry import WebIface
import os, pickle

from .CookieLogin.manager import LoginManager

#
# Setup CookieLogin
#
#
with open("chat/key-data.pik", "rb") as f:
	data = pickle.load(f)

key = data["key"]
pubkeys = data["pubkeys"]

# All password logins
logins = {"User": "verysecretpassword"}

# Functions used by LoginManager
def make_hash(string1, string2):
	if(not isinstance(string1, bytes)):
		string1 = string1.encode("UTF-8")
		string2 = string2.encode("UTF-8")
	return hashlib.sha256(string1 + string2).digest()
get_ip = lambda:  cherrypy.request.remote.ip
def set_cookie(c): 
	print(c)
	cherrypy.response.cookie["login"] = c
def remove_cookie(c): 
	print(c)
	cherrypy.response.cookie["login"] = ''

# hash the passwords
logins = {k: make_hash(k, v) for k,v in logins.items()}
get_passwd_hash = lambda name: logins[name]
get_expire_time = lambda name: datetime.timedelta(hours = 24)

manager = LoginManager(get_passwd_hash, set_cookie,
		make_hash, get_ip,
		get_expire_time, remove_cookie, 
		pubkeys, key)
#
# CookieLogin setup done
#
#



webif = WebIface(manager, path_prefix = "test/")

try:
	print( webif.api.to_json())
	webif.api.chats_by_ID[0].chat.users.append("User")
	webif.api.chats_by_ID[0].chat.mods.append("User")
except Exception as e: 
	print(repr(e))

conf = {\
	"/": {\
		'tools.sessions.on': True
	},
}
cherrypy.config.update({
	'server.socket_host': '0.0.0.0'
})
cherrypy.quickstart(webif, "/", conf)

